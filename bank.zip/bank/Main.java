class Main{

	Employee[] emp = null;
	public static void main(String[] args) {

		new Main();
	}

	Main(){
		emp = new Employee[3];
		emp[0] = new Employee("John Doe");
		emp[1] = new Employee("John william");
		emp[2] = new Employee("John wick");

		emp[0].createNewCheckingAcc(10000); 
		emp[0].createNewSavingAcc(10000);
		emp[0].createNewRetirementAcc(10000);

		emp[1].createNewCheckingAcc(20000); 
		emp[1].createNewSavingAcc(20000);
		emp[1].createNewRetirementAcc(20000);

		emp[2].createNewCheckingAcc(30000); 
		emp[2].createNewSavingAcc(30000);
		emp[2].createNewRetirementAcc(30000);

		emp[0].deposit(AccountType.SAVING,5000);

		emp[1].withdraw(AccountType.RETIREMENT,5000);

		for(Employee e :emp){
			
			System.out.println(e.formattedAccountInfo());
			System.out.println();
		}

	}
}