
class Employee{

	private Account savingAccount;
	private Account checkingAccount;
	private Account retirementAccount;
	private String name;

	Employee(String name){
		this.name = name;
	}

	void createNewSavingAcc(double startingBalance){
		savingAccount = new Account(this,AccountType.SAVING,startingBalance);
	}

	void createNewCheckingAcc(double startingBalance){
		checkingAccount = new Account(this,AccountType.CHECKING,startingBalance);
	}

	void createNewRetirementAcc(double startingBalance){
		retirementAccount = new Account(this,AccountType.RETIREMENT,startingBalance);
	}

	void deposit(String accountType,double amount){

		switch(accountType){
		case AccountType.CHECKING:
			checkingAccount.makeDeposit(amount);
			break;
		case AccountType.SAVING:
			savingAccount.makeDeposit(amount);
			break;
		case AccountType.RETIREMENT:
			retirementAccount.makeDeposit(amount);
			break;
		}
	}

	boolean withdraw(String accountType,double amount){

		switch(accountType){
			case AccountType.CHECKING:
			return checkingAccount.makeWithdraw(amount);		
		case AccountType.SAVING:
			return savingAccount.makeWithdraw(amount);
			
		case AccountType.RETIREMENT:
			return retirementAccount.makeWithdraw(amount);
		}

		return false;
	}

	String getName(){
		return name;
	}

	String formattedAccountInfo(){
		return String.format(
			"Account Info For %s .\nAccount Type : %s\nCurrent Balance :%s\nAccount Type : %s\nCurrent Balance :%s\nAccount Type :%s\nCurrent Balance :%s"
			,getName()
			,AccountType.CHECKING
			,checkingAccount.getBalance()
			,AccountType.SAVING
			,savingAccount.getBalance()
			,AccountType.RETIREMENT
			,retirementAccount.getBalance()

		);
	}

}