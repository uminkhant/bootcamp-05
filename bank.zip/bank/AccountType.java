class AccountType{
		static final String CHECKING = "checking account";
		static final String SAVING = "saving account";
		static final String RETIREMENT = "retirement account";
	}