class Account{

private Employee employee;
private String accountType;
private double balance;

Account(Employee employee,String accountType,double balance){
	this.employee = employee;
	this.accountType = accountType;
	this.balance = balance;
}


void makeDeposit(double amount){
	balance += amount;
}

boolean makeWithdraw(double amount){

	if(balance > amount){
		balance -= amount;
		return true;
	}
	return false;
}

double getBalance(){
	return balance;
}

	
}