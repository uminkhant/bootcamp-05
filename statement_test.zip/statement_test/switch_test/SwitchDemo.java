class SwitchDemo{

	static final String MON = "MON";
	static final String TUE ="TUE";
	static final String WED = "WED";
	static final String THUR = "THUR";
	static final String FRI = "FRI";
	static final String SAT = "SAT";
	static final String SUN = "SUN";

	public static void main(String[] args) {
		String res = checkWorkDay(MON);
		System.out.println(res);
	}

	static String checkWorkDay(String day){
		return	switch (day){
		case MON,TUE,WED,THUR,FRI -> "WORK DAY";
		case SAT,SUN -> "OFF DAY";
		default ->"OTHER";
		};
		
	}

	// static String checkWorkDay(String day){
	// 	switch (day){
	// 	case MON:
	// 	case TUE:
	// 	case WED:
	// 	case THUR:
	// 	case FRI:		
	// 	return "Work Day ";
	// 	case SUN:
	// 	case SAT:
	// 	return "Off Day";

	// 	}
	// 	return "Something wrong";	
	// }

	// static void checkWorkDay(String day){
	// 	switch (day){
	// 	case MON:
	// 	case TUE:
	// 	case WED:
	// 	case THUR:
	// 	case FRI:
	// 	System.out.println("Work Day ");
	// 	break;
	// 	case SUN:
	// 	case SAT:
	// 	System.out.println("Off Day !");
	// 	break;	
	// 	}
	// }

}