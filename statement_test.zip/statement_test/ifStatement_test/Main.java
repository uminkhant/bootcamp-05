import java.util.Scanner;

class Main{

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please type subject result marks !");
		int result = sc.nextInt();
		examResult(result);
	}

	static void examResult(int marks){
		if(marks >= 0 && marks < 40){
			System.out.println("fail exam ");
		}else if( marks >= 40 && marks < 80){
			System.out.println("Pass  exam !");
		}else if( marks >= 80 && marks <= 100){
			System.out.println("D");
		}else{
			System.out.println("Something wrong !");
		}
	}
}