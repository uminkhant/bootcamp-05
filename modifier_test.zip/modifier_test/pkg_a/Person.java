package modifier_test.pkg_a;

public class Person{
	
	private void privateMethod(){
		System.out.println("Using private");
	}

	void defaultMethod(){
		System.out.println("Using default");
	}
	protected void protectedMethod(){
		System.out.println("Using protected ");
	}

	public void publicMethod(){
		System.out.println("Using public");
	}
}