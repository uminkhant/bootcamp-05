package modifier_test.pkg_a;

class Main{
	public static void main(String[] args) {
		
		Person p = new Person();
		//p.privateMethod();
		p.defaultMethod();
		p.protectedMethod();
		p.publicMethod();
	}
}