package modifier_test.pkg_b;

import modifier_test.pkg_a.Person;

class OtherPkgMain {

	public static void main(String[] args) {
		Person p = new Person();
		//p.privateMethod();
		//p.defaultMethod();
		// p.protectedMethod();
		p.publicMethod();
	}
}