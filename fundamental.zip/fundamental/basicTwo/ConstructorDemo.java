class ConstructorDemo{

	public static void main(String[] args) {

		
		System.out.println("Before Constructor ");

		Person p = new Person();

		p.setName("Zin Ko");

		String name = p.getName();
		System.out.println(name);

	}
}