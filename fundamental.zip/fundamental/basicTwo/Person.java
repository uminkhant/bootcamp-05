class Person{

	 String name;

	Person(){}

	Person(String name){
		this.name = name;
		System.out.println("Using Constructor !");
	}

	 void setName(String name){
		this.name = name;
	}

	String getName(){
		return name;
	}
}