
class MethodDemo{

	static String name;

	public static void main(String[] args) {
		MethodDemo.doSomething();
	}

	static void doSomething(){
		 MethodDemo demo = new MethodDemo();
		// demo.doWork();
		MethodDemo.name ="Hello";
		 System.out.println("Hello");
	}

	void doWork(){
		name = "String";
		doSomething();
		System.out.println("invoke, instance method");
	}


}