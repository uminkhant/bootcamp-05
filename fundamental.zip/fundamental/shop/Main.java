package shop;
import shop.model.Item;
import java.util.Scanner;

public class Main{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Please type item name !");

	    String name = sc.next();

	    System.out.println("Please type qty !");

	    int qty = sc.nextInt();

	    System.out.println("Please typ price !");

	    int price  = sc.nextInt();

	    Item item = new Item(name,qty,price);


	    item.showItem();

	}
}