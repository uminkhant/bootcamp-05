package shop.model;

public class Item{

	String name;
	int qty;
	int price;

	public Item(String name , int qty,int price){
		this.name = name;
		this.qty = qty;
		this.price = price;
	}

	public void showItem(){
		System.out.println("Item : "+name);
		System.out.println("Qty : "+qty);
		System.out.println("Price : "+price);
		System.out.println("Total : "+(price*qty));
	}
}