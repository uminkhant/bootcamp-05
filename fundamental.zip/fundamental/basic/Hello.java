class Hello{

	static String str;

	public static void main (String[]arg){

		// Counter c1 = new Counter();
		// c1.instanceData = 10 ;
		// Counter.staticData =10;

		// Counter c2 = new Counter();

		// System.out.println("Instatnce Data  c1:c2 "+c1.instanceData +"\t"+c2.instanceData);
		// System.out.println("Static Data  c1:c2 "+Counter.staticData +"\t"+Counter.staticData);
		
		 str = "we do something !";
		doSomething("we do nothing !");
	}

	static void doSomething(String str){
		
		System.out.println(str);
	}

	
}

