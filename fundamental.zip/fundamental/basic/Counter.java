class Counter{

	static int staticData;
	int instanceData;
}