
class MethodStructureDemo{

	String str;
	int age;
	static String name;

	public static void main(String[] args) {
		
		MethodStructureDemo demo = new MethodStructureDemo();
		
		demo.setData("Soe thu",23);
		String res = demo.showData();
		System.out.println(res);
		
	}

	void setData(String str,int age){
		this.str = str;
		this.age = getAge();
		name = "moe moe ";
	}

	static int getAge(){
		return 45;
	}


	 String showData(){

		return str +" is "+age+" yrs old.";
	}
}