package package_test.pkg_one;

public class Data{
	int value;

	public static String str;

	public static void greeting(String name){
		System.out.println("Hello ! "+name);
	}

	public void setValue(int value){
		this.value = value;
	}

	public int getValue(){
		return value;
	}
}