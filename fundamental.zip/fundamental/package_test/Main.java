package package_test;

import package_test.pkg_one.Data;
import static package_test.pkg_one.Data.*;
//import static package_test.pkg_one.Data.str;

class Main{
	public static void main(String[] args) {
		Data d = new Data();
		d.setValue(40);
		int a = d.getValue();

		System.out.println(a);
		str = "sss";
		greeting("Wai yan");
	}
}